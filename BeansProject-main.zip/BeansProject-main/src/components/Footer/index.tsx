import styles from "./styles.module.css";

export const Footer = () => {
  return (
    <footer className={styles.container}>
      © Created by Margarita Shpileva , 2024
    </footer>
  );
};

import styles from "./styles.module.css";

export const Error = () => {
  return (
    <div className={styles.wrapper}>
      <h3>Упс, что-то не так..</h3>
    </div>
  );
};

import { useEffect, useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import { useSelector } from "react-redux";
import { Error } from "../../components/Error";
import { Loader } from "../../components/Loader";
import { historySelector } from "../../Redux/history/historySelector"; // селектор для истории
import { useAppDispatch } from "../../Redux/store";
import { getHistory } from "../../api/history"; // API для получения истории
import "./styles.css";

const History = () => {
  const dispatch = useAppDispatch();
  const { data, totalPages, isLoading, isError } = useSelector(historySelector);
  const [page, setPage] = useState(1);

  useEffect(() => {
    dispatch(getHistory(page));
  }, [dispatch, page]);

  const load = () => {
    setPage(page + 1);
  };

  return (
    <div className="history_container">
      <h1>History ...</h1>
      {isLoading && data.length === 0 ? (
        <Loader />
      ) : (
        <InfiniteScroll
          next={load}
          dataLength={data.length}
          loader={<Loader />}
          hasMore={page < totalPages}
        >
          <ul>
            {data.map((item) => (
              <li key={`history_item_${item.mileStoneId}`}>
                <h3>{item.year}</h3>
                <p className="infinite-scroll-component">{item.mileStoneId}</p>
                <p className="item">{item.description}</p>
              </li>
            ))}
          </ul>
        </InfiniteScroll>
      )}
      {isError && <Error />}
    </div>
  );
};

export default History;
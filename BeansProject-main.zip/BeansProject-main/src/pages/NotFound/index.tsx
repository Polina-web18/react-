import "./styles.css";

export const NotFound = () => {
  return (
    <div className="not_found_container">
      <h1>Not Found</h1>
    </div>
  );
};

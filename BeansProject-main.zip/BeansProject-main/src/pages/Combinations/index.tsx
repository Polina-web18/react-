import { useEffect, useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import { useSelector } from "react-redux";
import { Error } from "../../components/Error";
import { Loader } from "../../components/Loader";
import { combinationsSelector } from "../../Redux/combinations/combinationsSelector"; //  селектор для комбинаций
import { useAppDispatch } from "../../Redux/store";
import { getCombinations } from "../../api/combinations"; // API для получения комбинаций
import "./styles.css";

const Combinations = () => {
  const dispatch = useAppDispatch();
  const { data, totalPages, isLoading, isError } = useSelector(combinationsSelector);
  const [page, setPage] = useState(1);

  useEffect(() => {
    dispatch(getCombinations(page));
  }, [dispatch, page]);

  const load = () => {
    setPage(page + 1);
  };

  return (
    <div className="combinations_container">
      <h1>Combinations ...</h1>
      {isLoading && data.length === 0 ? (
        <Loader />
      ) : (
        <InfiniteScroll
          next={load}
          dataLength={data.length}
          loader={<Loader />}
          hasMore={page < totalPages}
        >
          <ul>
            {data.map((item) => (
              <li key={`combination_item_${item.combinationId}`}>
              </li>
            ))}
          </ul>
        </InfiniteScroll>
      )}
      {isError && <Error />}
    </div>
  );
};

export default Combinations;
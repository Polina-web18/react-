import { useEffect, useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import { useSelector } from "react-redux";
import { Error } from "../../components/Error";
import { RecipeCard } from "../../components/RecipeCard"; 
import { Loader } from "../../components/Loader";
import { RecipesSelector } from "../../Redux/recipes/recipesSelector"; //  селектор для рецептов
import { useAppDispatch } from "../../Redux/store";
import { getRecipes } from "../../api/recipes"; //  API для получения рецептов
import "./styles.css";

const Recipes = () => {
  const dispatch = useAppDispatch();
  const { data, totalPages, isLoading, isError } = useSelector(RecipesSelector);
  const [page, setPage] = useState(1);

  useEffect(() => {
    dispatch(getRecipes(page));
  }, [dispatch, page]);

  const load = () => {
    setPage(page + 1);
  };

  return (
    <div className="recipes_container">
      <h1>Recipes ...</h1>
      {isLoading && data.length === 0 ? (
        <Loader />
      ) : (
        <InfiniteScroll
          next={load}
          dataLength={data.length}
          loader={<Loader />}
          hasMore={page < totalPages}
        >
          {data.map((item) => (
            <RecipeCard key={`recipe_item_${item.recipeId}`} data={item} />
          ))}
        </InfiniteScroll>
      )}
      {isError && <Error />}
    </div>
  );
};

export default Recipes;